package com.example.listener;


public interface OnDualPaneShowListener
{
	void onDualPaneShow(Class<?> targetFragment, int index);
}
