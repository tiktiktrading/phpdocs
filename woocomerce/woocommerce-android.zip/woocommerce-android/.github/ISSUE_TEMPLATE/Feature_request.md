---
name: "\U0001F680 Feature request"
about: "Suggest a new feature \U0001F389 We'll consider building it if it receives sufficient interest! \U0001F44D"

---

Please submit all feature requests to the ideas board located at http://ideas.woocommerce.com/forums/133476-woocommerce?category_id=84283.
