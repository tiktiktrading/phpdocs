package com.woocommerce.android.ui.orders

import android.os.Build.VERSION
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.espresso.matcher.ViewMatchers.Visibility.GONE
import androidx.test.espresso.matcher.ViewMatchers.Visibility.VISIBLE
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import com.woocommerce.android.R
import com.woocommerce.android.ui.TestBase
import com.woocommerce.android.ui.main.MainActivityTestRule
import org.junit.Assume
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.wordpress.android.fluxc.model.SiteModel

/**
 * Related FluxC issue in MockedStack_WCBaseStoreTest.kt#L116
 * Some of the internals of java.util.Currency seem to be stubbed in a unit test environment,
 * giving results inconsistent with a normal running app.
 * So adding a check here that assumes the device testing takes place in devices above API 23.
 */
@RunWith(AndroidJUnit4::class)
@LargeTest
class OrderDetailPaymentCardTest : TestBase() {
    @Rule
    @JvmField var activityTestRule = MainActivityTestRule()

    @Before
    override fun setup() {
        super.setup()
        Assume.assumeTrue(
                "Requires API 23 or higher due to localized currency values differing on older versions",
                VERSION.SDK_INT >= 23
        )

        // Bypass login screen and display dashboard
        activityTestRule.launchMainActivityLoggedIn(null, SiteModel())

        // Make sure the bottom navigation view is showing
        activityTestRule.activity.showBottomNav()

        // add mock data to order list screen
        activityTestRule.setOrderListWithMockData()

        // Click on Orders tab in the bottom bar
        onView(withId(R.id.orders)).perform(click())
    }

    @Test
    fun verifyPaymentCardViewPopulatedSuccessfully() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                orderStatus = "processing",
                paymentMethodTitle = "Credit Card (Stripe)",
                discountTotal = "4",
                datePaidString = "2018-02-02T16:11:13Z"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // check if order payment card label matches this title: R.string.payment
        onView(withId(R.id.paymentInfo_lblTitle)).check(matches(withText(appContext.getString(R.string.payment))))

        // check if order payment card sub total label matches this title: R.string.products_total
        onView(withId(R.id.paymentInfo_lblProductsTotal))
                .check(matches(withText(appContext.getString(R.string.products_total))))

        // check if order payment card shipping label matches this title: R.string.shipping
        onView(withId(R.id.paymentInfo_lblShipping)).check(matches(withText(appContext.getString(R.string.shipping))))

        // check if order payment card taxes label matches this title: R.string.taxes
        onView(withId(R.id.paymentInfo_lblTaxes)).check(matches(withText(appContext.getString(R.string.taxes))))

        // check if order payment card total label matches this title: R.string.total
        onView(withId(R.id.paymentInfo_lblTotal)).check(matches(withText(appContext.getString(R.string.order_total))))

        // Since discount is available, check if order payment card discount label matches this title: R.string.discount
        onView(withId(R.id.paymentInfo_lblDiscount)).check(matches(withText(appContext.getString(R.string.discount))))

        // since payment is set to Processing, and order.paymentMethodTitle is not empty,
        // the payment method message should be visible
        onView(withId(R.id.paymentInfo_paymentMsg)).check(matches(ViewMatchers.withEffectiveVisibility(VISIBLE)))
        onView(withId(R.id.paymentInfo_paymentMsg)).check(matches(withText(appContext.getString(
                R.string.orderdetail_payment_summary_completed,
                "Feb 2, 2018",
                "Credit Card (Stripe)")
        )))
    }

    @Test
    fun verifyPaymentMethodTitleHiddenIfNotAvailable() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail()
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // since order.paymentMethodTitle is empty, the payment method message should not be visible
        onView(withId(R.id.paymentInfo_paymentMsg)).check(matches(ViewMatchers.withEffectiveVisibility(GONE)))
    }

    @Test
    fun verifyPaymentCardViewPopulatedSuccessfullyForEuro() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                currency = "EUR", paymentMethodTitle = "Credit Card (Stripe)", datePaidString = "2018-02-02T16:11:13Z"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // check if order payment card sub total matches this text
        onView(withId(R.id.paymentInfo_productsTotal)).check(matches(withText("€22.00")))

        // check if order payment card shipping total matches this text
        onView(withId(R.id.paymentInfo_shippingTotal)).check(matches(withText("€12.00")))

        // check if order payment card tax total matches this text
        onView(withId(R.id.paymentInfo_taxesTotal)).check(matches(withText("€2.00")))

        // check if order payment card total matches this text
        onView(withId(R.id.paymentInfo_total)).check(matches(withText("€44.00")))

        // check if order paid by customer matches this text
        onView(withId(R.id.paymentInfo_paid)).check(matches(withText("€44.00")))

        // check if order payment message messages this text
        onView(withId(R.id.paymentInfo_paymentMsg)).check(matches(withText(appContext.getString(
                R.string.orderdetail_payment_summary_completed,
                "Feb 2, 2018",
                mockWCOrderModel.paymentMethodTitle)
        )))
    }

    @Test
    fun verifyPaymentCardViewPopulatedSuccessfullyForUsd() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                paymentMethodTitle = "Credit Card (Stripe)", datePaidString = "2018-02-02T16:11:13Z"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // check if order payment card sub total matches this text
        onView(withId(R.id.paymentInfo_productsTotal)).check(matches(withText("$22.00")))

        // check if order payment card shipping total matches this text
        onView(withId(R.id.paymentInfo_shippingTotal)).check(matches(withText("$12.00")))

        // check if order payment card tax total matches this text
        onView(withId(R.id.paymentInfo_taxesTotal)).check(matches(withText("$2.00")))

        // check if order payment card total matches this text
        onView(withId(R.id.paymentInfo_total)).check(matches(withText("$44.00")))

        // check if order paid by customer matches this text
        onView(withId(R.id.paymentInfo_paid)).check(matches(withText("$44.00")))

        onView(withId(R.id.paymentInfo_paymentMsg)).check(matches(withText(appContext.getString(
                R.string.orderdetail_payment_summary_completed,
                "Feb 2, 2018",
                mockWCOrderModel.paymentMethodTitle)
        )))
    }

    @Test
    fun verifyPaymentCardViewPopulatedSuccessfullyForInr() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                currency = "INR", paymentMethodTitle = "Credit Card (Stripe)", datePaidString = "2018-02-02T16:11:13Z"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // check if order payment card sub total matches this text
        onView(withId(R.id.paymentInfo_productsTotal)).check(matches(withText("₹22.00")))

        // check if order payment card shipping total matches this text
        onView(withId(R.id.paymentInfo_shippingTotal)).check(matches(withText("₹12.00")))

        // check if order payment card tax total matches this text
        onView(withId(R.id.paymentInfo_taxesTotal)).check(matches(withText("₹2.00")))

        // check if order payment card total matches this text
        onView(withId(R.id.paymentInfo_total)).check(matches(withText("₹44.00")))

        // check if order paid by customer matches this text
        onView(withId(R.id.paymentInfo_paid)).check(matches(withText("₹44.00")))

        onView(withId(R.id.paymentInfo_paymentMsg)).check(matches(withText(appContext.getString(
                R.string.orderdetail_payment_summary_completed,
                "Feb 2, 2018",
                mockWCOrderModel.paymentMethodTitle)
        )))
    }

    @Test
    fun verifyPaymentCardViewNoDiscountHidden() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail()
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // since no discounts are applicable, the section should be hidden
        onView(withId(R.id.paymentInfo_discountSection)).check(matches(ViewMatchers.withEffectiveVisibility(GONE)))
    }

    @Test
    fun verifyPaymentCardViewNoRefundHidden() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail()
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // Since no refund is available, the section should be hidden:
        onView(withId(R.id.paymentInfo_refundSection)).check(matches(ViewMatchers.withEffectiveVisibility(GONE)))

        // check if order payment card label matches this title: R.string.payment
        onView(withId(R.id.paymentInfo_lblTitle)).check(matches(withText(appContext.getString(R.string.payment))))
    }

    @Test
    fun verifyPaymentCardViewWithRefundPopulatedSuccessfully() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                refundTotal = -4.25,
                paymentMethodTitle = "Credit Card (Stripe)",
                datePaidString = "2018-02-02T16:11:13Z"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // There are refunds, the section should be visible:
        onView(withId(R.id.paymentInfo_refundSection)).check(matches(ViewMatchers.withEffectiveVisibility(VISIBLE)))

        // verify that the refund total is displayed
        onView(withId(R.id.paymentInfo_refundTotal)).check(matches(withText("$4.25")))

        // verify that the new payment total is displayed
        onView(withId(R.id.paymentInfo_newTotal)).check(matches(withText("$39.75")))
    }

    @Test
    fun verifyPaymentCardViewWithSingleDiscountPopulatedSuccessfully() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                discountTotal = "10", discountCodes = "30dayhoodiesale"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // Since discount is available, check if it is displayed
        onView(withId(R.id.paymentInfo_discountSection)).check(matches(ViewMatchers.withEffectiveVisibility(VISIBLE)))

        // Since discount is available, check if the amount = 10
        onView(withId(R.id.paymentInfo_discountTotal)).check(matches(withText("$10.00")))

        // Since discount is available, check if the discount code = 30dayhoodiesale
        onView(withId(R.id.paymentInfo_discountItems)).check(matches(withText(
                appContext.getString(R.string.orderdetail_discount_items, mockWCOrderModel.discountCodes)
        )))
    }

    @Test
    fun verifyPaymentCardViewWithMultipleDiscountsPopulatedSuccessfully() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                discountTotal = "22.40", discountCodes = "30dayhoodiesale, 10dollaroff100"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // Since discount is available, check if it is displayed
        onView(withId(R.id.paymentInfo_discountSection)).check(matches(ViewMatchers.withEffectiveVisibility(VISIBLE)))

        // Since discount is available, check if the amount = 122.40
        onView(withId(R.id.paymentInfo_discountTotal)).check(matches(withText("$22.40")))

        // Since discount is available, check if the discount code = 30dayhoodiesale, 10dollaroff100
        onView(withId(R.id.paymentInfo_discountItems)).check(matches(withText(
                appContext.getString(R.string.orderdetail_discount_items, mockWCOrderModel.discountCodes)
        )))
    }

    @Test
    fun verifyPaymentCardViewWaitingForPayment() {
        val mockWCOrderModel = WcOrderTestUtils.generateOrderDetail(
                paymentMethodTitle = "Cash on Delivery"
        )
        activityTestRule.setOrderDetailWithMockData(mockWCOrderModel)

        // click on the first order in the list and check if redirected to order detail
        onView(withId(R.id.ordersList))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click()))

        // check if order payment card sub total matches this text
        onView(withId(R.id.paymentInfo_productsTotal)).check(matches(withText("$22.00")))

        // check if order payment card shipping total matches this text
        onView(withId(R.id.paymentInfo_shippingTotal)).check(matches(withText("$12.00")))

        // check if order payment card tax total matches this text
        onView(withId(R.id.paymentInfo_taxesTotal)).check(matches(withText("$2.00")))

        // check if order payment card total matches this text
        onView(withId(R.id.paymentInfo_total)).check(matches(withText("$44.00")))

        // check if order paid by customer matches this text
        onView(withId(R.id.paymentInfo_paid)).check(matches(withText("$0.00")))

        onView(withId(R.id.paymentInfo_paymentMsg)).check(matches(withText(appContext.getString(
                R.string.orderdetail_payment_summary_onhold,
                mockWCOrderModel.paymentMethodTitle)
        )))
    }
}
