package com.woocommerce.android.annotations

@Target(AnnotationTarget.ANNOTATION_CLASS)
annotation class OpenClass
