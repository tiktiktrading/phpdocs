package com.woocommerce.android.annotations

@OpenClass
@Target(AnnotationTarget.CLASS)
annotation class OpenClassOnDebug
