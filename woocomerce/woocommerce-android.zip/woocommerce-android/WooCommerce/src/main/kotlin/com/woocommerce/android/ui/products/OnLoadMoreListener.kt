package com.woocommerce.android.ui.products

interface OnLoadMoreListener {
    fun onRequestLoadMore()
}
