package com.woocommerce.android.ui.orders.list

enum class OrderListType {
    ALL,
    PROCESSING,
    SEARCH
}
