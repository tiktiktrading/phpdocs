package com.woocommerce.android.ui.mystore

interface MyStoreStatsAvailabilityListener {
    fun onMyStoreStatsRevertedNoticeCardDismissed()
    fun onMyStoreStatsAvailabilityAccepted()
    fun onMyStoreStatsAvailabilityRejected()
}
