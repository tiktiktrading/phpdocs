package com.woocommerce.android

object JobServiceIds {
    const val JOB_FCM_REGISTRATION_SERVICE_ID = 1000
    const val JOB_PRODUCT_IMAGES_SERVICE_ID = 2000
}
