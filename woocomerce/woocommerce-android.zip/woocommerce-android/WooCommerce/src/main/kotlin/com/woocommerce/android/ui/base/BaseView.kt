package com.woocommerce.android.ui.base

interface BaseView<T>
