package com.woocommerce.android.ui.orders

interface AddOrderTrackingProviderActionListener {
    fun onTrackingProviderSelected(selectedCarrierName: String)
}
